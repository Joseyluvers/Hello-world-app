import { useState } from 'react';

function App() {
  const [message, setMessage] = useState("Hello World");

  const handleClick = () => {
    setMessage("You clicked the button!");
  };

  return (
    <main style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>{message}</h1>
      <button onClick={handleClick}>Click Me</button>
    </main>
  );
}

export default App;